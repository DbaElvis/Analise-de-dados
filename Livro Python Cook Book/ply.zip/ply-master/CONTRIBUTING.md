Contributing to PLY
===================

PLY is a mature project. However, if you feel that you have found a
bug in PLY or its documentation, please submit an issue in the form
of a bug report at https://github.com/dabeaz/ply.  Pull requests
to the project are not accepted. 
