/* ë */
#define x 1