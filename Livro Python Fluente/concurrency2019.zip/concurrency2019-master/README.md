# concurrency-2019

Examples and exercises for a 3h workshop on Python concurrent programming techniques
